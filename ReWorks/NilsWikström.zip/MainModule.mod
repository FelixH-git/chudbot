MODULE MainModule

    VAR ShapeJob currentJob;
    VAR string servermMessage;
    VAR string clinetMessage;
    VAR bool connected := FALSE;

    ! Pick target, shared with moveToShape.


    PROC main()

        ! 1. Connect to Python first
        RobotAsClientConnect;
        !MoveJ pStar, v1000, z50, tsuck\WObj:=wobjAiPlaceTray;

        WHILE TRUE DO
            servermMessage := RobotClientReciveMessage();

            IF ParseJobString(servermMessage, currentJob) THEN

                IF currentJob.job_Shape = "exit" THEN
                    clinetMessage := "time TO DIE";
                    RobotClienSendMessage(clinetMessage);
                    RobotClientCloseAndDisconnect;
                    EXIT;
                ENDIF

                ! 2. Inherit the safe downward wrist orientation from pHome
                shape := pHome;

                ! 3. Apply the AI coordinates to X and Y
                shape.trans.x := currentJob.x_val;
                shape.trans.y := currentJob.y_val;

                ! 4. Pick height in wobjAruco (larger Z = higher)
                shape.trans.z := 0.0;

                ! No rotation here: the pick happens unrotated.
                ! The n-fold offset angle is applied after the piece is lifted.

                PrintRobtarget(shape);
                TPWrite "Shape: " + currentJob.job_Shape + "  Offset: " + NumToStr(currentJob.rz_val, 1);

                ! 5. Pick, rotate, place
                move_to_shape currentJob.job_Shape, currentJob.rz_val;

            ELSE
                IF servermMessage <> "" THEN
                    TPWrite "parse failed " + servermMessage;
                ENDIF
            ENDIF

        ENDWHILE

    ENDPROC

    PROC PrintRobtarget(robtarget p)
        TPWrite "X: " + NumToStr(p.trans.x, 2);
        TPWrite "Y: " + NumToStr(p.trans.y, 2);
        TPWrite "Z: " + NumToStr(p.trans.z, 2);
    ENDPROC

    PROC suckOn()
        SetDO doValve2, 1;
    ENDPROC

    PROC suckOff()
        SetDO doValve2, 0;
    ENDPROC

    PROC waitforOK(string action)
        TPWrite action;
        WaitDI diOkButton, 1;
        WaitDI diOkButton, 0;
        TPWrite "Performing " + action;
    ENDPROC

ENDMODULE