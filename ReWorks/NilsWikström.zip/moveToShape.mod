MODULE moveToShape

    ! Direction of the correction.
    ! -1: the AI offset is how far the piece is rotated, so turn it back.
    !  1: the AI offset is the correction to apply.
    ! If a test piece lands at double its angle instead of straight, flip this.
    CONST num ROT_SIGN := -1;

    ! Lift / approach height above pick and place targets (mm)
    CONST num LIFT := 50;

    PROC move_to_shape(string shape_input, num rz)
        VAR num rot;

        waitforOK("");

        ! 1. Approach and pick WITHOUT rotation
        !    MoveJ: coming from the tray (or wherever the robot is), long move
        MoveJ RelTool(shape, 0, 0, -LIFT), v100, fine, tsuck\WObj:=wobjAruco;
        MoveL shape, v50, fine, tsuck\WObj:=wobjAruco;
        suckOn;
        WaitTime 1.0;

        ! 2. Lift straight up, still unrotated
        MoveL RelTool(shape, 0, 0, -LIFT), v100, fine, tsuck\WObj:=wobjAruco;

        ! 3. Piece is held: rotate in place by the shortest correction
        rot := NormAngle(shape_input, ROT_SIGN * rz);
        TPWrite "Correction: " + NumToStr(rot, 1) + " deg";
        MoveL RelTool(shape, 0, 0, -LIFT \Rz:=rot), v50, fine, tsuck\WObj:=wobjAruco;

        ! 4. Go straight to the slot, keeping the correction
        IF shape_input = "Star" THEN
            PlaceAt pStar, rot;
        ELSEIF shape_input = "Square" THEN
            PlaceAt pSquare, rot;
        ELSEIF shape_input = "Hexagon" THEN
            PlaceAt pHexagon, rot;
        ELSEIF shape_input = "Circle" THEN
            PlaceAt pCircle, rot;
        ELSEIF shape_input = "Triangle" THEN
            PlaceAt pTriangle, rot;
        ELSE
            ! Unknown shape: put it back where it came from and release
            TPWrite "Unknown shape: " + shape_input;
            MoveL RelTool(shape, 0, 0, -LIFT), v100, fine, tsuck\WObj:=wobjAruco;
            MoveL shape, v50, fine, tsuck\WObj:=wobjAruco;
            suckOff;
            WaitTime 0.5;
            MoveL RelTool(shape, 0, 0, -LIFT), v100, fine, tsuck\WObj:=wobjAruco;
            RETURN;
        ENDIF
    ENDPROC

    PROC PlaceAt(robtarget pPlace, num rot)
        VAR robtarget pTarget;

        pTarget := RelTool(pPlace, 0, 0, 0 \Rz:=rot);

        ! MoveJ: long move from the pick area to above the slot
        MoveJ RelTool(pTarget, 0, 0, -LIFT), v100, fine, tsuck\WObj:=wobjAiPlaceTray;
        MoveL pTarget, v50, fine, tsuck\WObj:=wobjAiPlaceTray;
        WaitTime 1.0;
        suckOff;
        WaitTime 0.3;
        MoveL RelTool(pTarget, 0, 0, -LIFT), v100, fine, tsuck\WObj:=wobjAiPlaceTray;
    ENDPROC

    ! Reduces the angle to the shortest turn using the shape's n-fold symmetry.
    ! Period = 360/n. Result is in (-period/2, +period/2].
    ! These n values must match the ones used in the Python symmetry calc.
    FUNC num NormAngle(string shape_input, num a)
        VAR num n;
        VAR num sym;

        IF shape_input = "Triangle" THEN
            n := 3;
        ELSEIF shape_input = "Square" THEN
            n := 4;
        ELSEIF shape_input = "Star" THEN
            n := 5;
        ELSEIF shape_input = "Hexagon" THEN
            n := 6;
        ELSE
            ! Circle or unknown: no meaningful angle, don't rotate
            RETURN 0;
        ENDIF

        sym := 360 / n;

        WHILE a > sym / 2 DO
            a := a - sym;
        ENDWHILE
        WHILE a <= -sym / 2 DO
            a := a + sym;
        ENDWHILE

        RETURN a;
    ENDFUNC

ENDMODULE